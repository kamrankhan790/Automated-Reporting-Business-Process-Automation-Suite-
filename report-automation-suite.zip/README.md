# Automated Reporting & Business Process Automation Suite

Consolidates multiple raw Excel files into a single validated dataset and
generates a formatted, ready-to-send report. Designed to plug into a
scheduled trigger (e.g., Power Automate) for a fully hands-off reporting
workflow.

## What it does

1. Reads every `.xlsx` file in a source folder and combines them.
2. Applies basic data-quality rules: removes duplicates, flags missing
   values, reports row counts before/after cleaning.
3. Writes a formatted Excel report (styled header row, autosized columns).

## Setup

```bash
pip install -r requirements.txt
```

Place your source Excel files in a folder named `raw_reports/` in the
project directory.

## Run

```bash
python report_automation.py
```

Output: `consolidated_report_<date>.xlsx`.

## Automation notes

This script is built to be triggered by Power Automate:
- A Scheduled Cloud Flow can run it on a timer (via a "Run a script" /
  Desktop Flow action, or by watching a OneDrive/SharePoint folder for new
  raw files).
- A follow-up Flow step can automatically email the output or upload it to
  a Teams/SharePoint folder, removing the manual "collect → clean → format
  → send" step entirely.
