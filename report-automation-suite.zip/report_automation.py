"""
Project 2: Automated Reporting & Business Process Automation Suite
---------------------------------------------------------------------
What this demonstrates (matches the JD's "automate reporting, Excel, Power Automate"):
  1. Consolidating multiple messy Excel files into one clean dataset
  2. Applying validation rules automatically
  3. Generating a formatted, ready-to-send Excel report
  4. A note on how Power Automate slots in to trigger/schedule/distribute it

Install deps:
    pip install pandas openpyxl --break-system-packages
"""

import glob
import pandas as pd
from openpyxl.styles import Font, PatternFill
from datetime import date


INPUT_FOLDER = "raw_reports/"   # drop your weekly/monthly source Excel files here
OUTPUT_FILE = f"consolidated_report_{date.today()}.xlsx"


def load_and_consolidate(folder: str) -> pd.DataFrame:
    """Read every .xlsx file in the folder and stack them into one DataFrame."""
    files = glob.glob(folder + "*.xlsx")
    frames = []
    for f in files:
        df = pd.read_excel(f)
        df["source_file"] = f
        frames.append(df)
    if not frames:
        raise FileNotFoundError(f"No .xlsx files found in {folder}")
    combined = pd.concat(frames, ignore_index=True)
    return combined


def validate_and_clean(df: pd.DataFrame) -> pd.DataFrame:
    """Apply basic data-quality rules: drop dupes, flag missing values, standardize types."""
    before = len(df)
    df = df.drop_duplicates()
    df = df.dropna(how="all")

    missing_report = df.isna().sum()
    print("Missing values per column:\n", missing_report[missing_report > 0])

    print(f"Rows before cleaning: {before} | after: {len(df)}")
    return df


def build_formatted_report(df: pd.DataFrame, output_path: str) -> None:
    """Write a formatted Excel report - bold header row, colored fill, autosized columns."""
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Consolidated")
        ws = writer.sheets["Consolidated"]

        header_fill = PatternFill(start_color="1F3864", end_color="1F3864", fill_type="solid")
        header_font = Font(color="FFFFFF", bold=True)
        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font

        for col_cells in ws.columns:
            length = max(len(str(c.value)) for c in col_cells if c.value is not None)
            ws.column_dimensions[col_cells[0].column_letter].width = length + 4

    print(f"Report saved to {output_path}")


if __name__ == "__main__":
    data = load_and_consolidate(INPUT_FOLDER)
    data = validate_and_clean(data)
    build_formatted_report(data, OUTPUT_FILE)

    # --- Where Power Automate comes in ---
    # 1. A Power Automate "Scheduled Cloud Flow" runs this script on a timer
    #    (via a "Run a script" / Desktop Flow action, or by watching a folder
    #    in OneDrive/SharePoint for new raw files).
    # 2. Once this script drops the output file, a second Flow step emails it
    #    automatically to stakeholders or uploads it to a Teams/SharePoint folder.
    # This turns a manual "collect -> clean -> format -> send" chore into a
    # scheduled, hands-off pipeline - the automation story the JD is asking for.
